![Metadrone](http://www.metadrone.com/img/mdlogo.png)

# Metadrone Source Code

This repo is the source for the code generator Metadrone (www.metadrone.com). Originally a closed source exercise started in 2008.

This project uses ICSharpCode.TextEditor for syntax highlighting. It is the text editor component for the SharpDevelop project. SharpDevelop is a free open source IDE. Although Metadrone is not a derivative work of ICSharpCode.TextEditor, this component has been altered for use with Metadrone.

## How to build

Metadrone is a Visual Basic project. Open the file /source/Metadrone.sln with Visual Studio 2017.

## Download

The download link for a compiled build is here: http://www.metadrone.com/download

