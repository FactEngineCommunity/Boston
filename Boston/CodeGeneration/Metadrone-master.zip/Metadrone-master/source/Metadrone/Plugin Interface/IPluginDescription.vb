﻿Namespace PluginInterface

    Public Interface IPluginDescription

        ReadOnly Property ProductInformation() As String
        ReadOnly Property LicenceInformation() As String

    End Interface

End Namespace