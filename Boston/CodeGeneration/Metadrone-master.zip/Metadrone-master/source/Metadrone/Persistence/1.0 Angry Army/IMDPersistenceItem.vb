﻿Namespace Persistence.AngryArmy_1_0

    Public Interface IMDPersistenceItem

        Function GetCopy() As IMDPersistenceItem

    End Interface

End Namespace