﻿Namespace Persistence.AngryArmy_1_0

    Public Interface IEditorItem

        Property EditorGUID() As String
        Property OwnerGUID() As String

    End Interface

End Namespace