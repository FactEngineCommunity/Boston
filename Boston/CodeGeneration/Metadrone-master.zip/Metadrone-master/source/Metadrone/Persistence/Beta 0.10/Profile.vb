﻿Namespace Persistence.Beta10

    <Serializable()> _
    Public Class Profile

        Public OpenEditorGUIDs As New List(Of String)
        Public SelectedEditorGUID As String

    End Class

End Namespace