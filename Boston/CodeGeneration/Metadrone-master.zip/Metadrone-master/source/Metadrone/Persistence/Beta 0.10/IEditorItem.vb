﻿Namespace Persistence.Beta10

    Public Interface IEditorItem

        Property EditorGUID() As String
        Property OwnerGUID() As String

    End Interface

End Namespace