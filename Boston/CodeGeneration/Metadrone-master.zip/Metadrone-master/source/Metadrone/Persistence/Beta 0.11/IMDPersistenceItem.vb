﻿Namespace Persistence.Beta11

    Public Interface IMDPersistenceItem

        Function GetCopy() As IMDPersistenceItem

    End Interface

End Namespace