﻿Namespace Parser.CodeCompletion

    Friend Class Template

        Public Name As String = ""
        Public Params As New List(Of String)

    End Class

End Namespace
