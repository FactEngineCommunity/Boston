﻿Imports Metadrone.Parser.Syntax.Constants
Imports Metadrone.Parser.Syntax.Strings
Imports Metadrone.Parser.Output

Namespace Parser.Syntax

    Friend Class PreProcessor
        Public IgnoreCase As Boolean = True
        Public Safe_Begin As String = Nothing
        Public Safe_End As String = Nothing
    End Class

End Namespace
